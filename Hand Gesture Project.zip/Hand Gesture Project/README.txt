Contents:

This contains the modified python code to use the neural network and send information to the Arduino board, Arduino code for connection and the 3D models for your own modification or assembly.

Running:

Once servos are connected correctly, upload the Arduino Code to the Arduino Board
Download mediapipe and OpenCV using pip install 
Run the python code and enjoy!

Troubleshoot:

You may find trouble running the code on your code editor. On VSCode some errors may be resolved by:

	- Using the correct interpreter for errors regarding the import cv2 as cv
	- Access Denied may be because you have the Arduino IDE open alongside the Python. Simply close the Arduino IDE and rerun the program
	- If using CodeRunner extension, may come across execution errors. Simply uninstall the one you are using and try again (may use another)


CREDITS:

Using the base mediapipe repository from Kazuhito Takahashi translated to English by Nikita Kiselov.